import React, { useState } from 'react';
import { View, StyleSheet, ScrollView, Text } from 'react-native';
import Button from '../../src/components/ui/Button';
import Input from '../../src/components/ui/Input';
import Card, { CardHeader, CardFooter } from '../../src/components/ui/Card';
import Select from '../../src/components/ui/Select';
import Checkbox from '../../src/components/ui/Checkbox';
import TextArea from '../../src/components/ui/TextArea';
import CategoryBadge from '../../src/components/activities/CategoryBadge';
import TokenDisplay from '../../src/components/ui/TokenDisplay';
import { lightTheme as theme } from '../../src/styles/theme';

export default function ComponentsScreen() {
  const [inputValue, setInputValue] = useState('');
  const [selectValue, setSelectValue] = useState('');
  const [checkboxValue, setCheckboxValue] = useState(false);
  const [indeterminateValue, setIndeterminateValue] = useState(false);
  const [textAreaValue, setTextAreaValue] = useState('');
  
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>UI Components</Text>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Category Badges</Text>
        <View style={styles.row}>
          <CategoryBadge category="educational" size="sm" />
          <CategoryBadge category="social" size="md" />
          <CategoryBadge category="house chores" size="lg" />
          <CategoryBadge category="physical" showIcon={false} />
        </View>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Token Display</Text>
        <View style={styles.row}>
          <View style={styles.tokenExample}>
            <Text style={styles.tokenLabel}>Small:</Text>
            <TokenDisplay amount={15} size="sm" />
          </View>
          <View style={styles.tokenExample}>
            <Text style={styles.tokenLabel}>Medium:</Text>
            <TokenDisplay amount={25} size="md" />
          </View>
          <View style={styles.tokenExample}>
            <Text style={styles.tokenLabel}>Large:</Text>
            <TokenDisplay amount={50} size="lg" />
          </View>
        </View>
        <View style={[styles.row, styles.marginTop]}>
          <Button 
            title="Animate Tokens" 
            onPress={() => {
              const tokenDisplay = document.getElementById('animated-token');
              if (tokenDisplay) {
                tokenDisplay.key = Date.now().toString();
              }
            }}
            style={styles.marginRight}
          />
          <View id="animated-token" key="initial">
            <TokenDisplay amount={100} size="xl" animated showPlus />
          </View>
        </View>
      </View>
      
      {/* Existing component sections */}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
    padding: theme.spacing.spacing.md,
  },
  title: {
    ...theme.typography.textStyle.h2,
    marginBottom: theme.spacing.spacing.xl,
    color: theme.colors.textPrimary,
  },
  section: {
    marginBottom: theme.spacing.spacing.xl,
  },
  sectionTitle: {
    ...theme.typography.textStyle.h3,
    marginBottom: theme.spacing.spacing.md,
    color: theme.colors.textPrimary,
  },
  row: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: theme.spacing.spacing.sm,
  },
  tokenExample: {
    alignItems: 'center',
  },
  tokenLabel: {
    ...theme.typography.textStyle.bodySmall,
    color: theme.colors.textSecondary,
    marginBottom: theme.spacing.spacing.xs,
  },
  marginTop: {
    marginTop: theme.spacing.spacing.md,
  },
  marginRight: {
    marginRight: theme.spacing.spacing.md,
  },
});