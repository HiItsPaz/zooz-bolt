import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import ParentLayout from '../../src/components/layout/ParentLayout';
import ChildLayout from '../../src/components/layout/ChildLayout';
import AdminLayout from '../../src/components/layout/AdminLayout';
import AuthLayout from '../../src/components/layout/AuthLayout';
import Button from '../../src/components/ui/Button';
import { lightTheme as theme } from '../../src/styles/theme';

export default function Home() {
  const [activeLayout, setActiveLayout] = React.useState<'parent' | 'child' | 'admin' | 'auth'>('parent');

  const handleMenuPress = (item: string) => {
    console.log('Menu item pressed:', item);
  };

  const handleProfilePress = () => {
    console.log('Profile pressed');
  };

  const handleNotificationPress = () => {
    console.log('Notifications pressed');
  };

  const footerLinks = [
    { id: 'terms', label: 'Terms', onPress: () => console.log('Terms pressed') },
    { id: 'privacy', label: 'Privacy', onPress: () => console.log('Privacy pressed') },
    { id: 'contact', label: 'Contact', onPress: () => console.log('Contact pressed') },
  ];

  const renderLayoutSelector = () => (
    <View style={styles.layoutSelector}>
      <Button
        title="Parent"
        variant={activeLayout === 'parent' ? 'primary' : 'outline'}
        onPress={() => setActiveLayout('parent')}
        size="sm"
      />
      <Button
        title="Child"
        variant={activeLayout === 'child' ? 'primary' : 'outline'}
        onPress={() => setActiveLayout('child')}
        size="sm"
      />
      <Button
        title="Admin"
        variant={activeLayout === 'admin' ? 'primary' : 'outline'}
        onPress={() => setActiveLayout('admin')}
        size="sm"
      />
      <Button
        title="Auth"
        variant={activeLayout === 'auth' ? 'primary' : 'outline'}
        onPress={() => setActiveLayout('auth')}
        size="sm"
      />
    </View>
  );

  const demoContent = (
    <View style={styles.demoContent}>
      <Text style={styles.heading}>Layout Components Demo</Text>
      <Text style={styles.paragraph}>
        This is a demonstration of the different layout components available in the Zooz app.
        Each layout is designed for a specific user role and provides a consistent structure for the app.
      </Text>
      <Text style={styles.paragraph}>
        You can switch between layouts using the buttons below to see how each one looks and functions.
      </Text>
      {renderLayoutSelector()}
    </View>
  );

  switch (activeLayout) {
    case 'parent':
      return (
        <ParentLayout
          userName="Sarah Johnson"
          unreadNotifications={3}
          onNotificationsPress={handleNotificationPress}
          onProfilePress={handleProfilePress}
          onMenuItemPress={handleMenuPress}
          footerLinks={footerLinks}
        >
          {demoContent}
        </ParentLayout>
      );
    
    case 'child':
      return (
        <ChildLayout
          userName="Tommy"
          tokenBalance={125}
          unreadNotifications={2}
          onNotificationsPress={handleNotificationPress}
          onProfilePress={handleProfilePress}
          onMenuItemPress={handleMenuPress}
        >
          {demoContent}
        </ChildLayout>
      );
    
    case 'admin':
      return (
        <AdminLayout
          userName="Admin User"
          unreadNotifications={5}
          onNotificationsPress={handleNotificationPress}
          onProfilePress={handleProfilePress}
          onMenuItemPress={handleMenuPress}
          footerLinks={footerLinks}
        >
          {demoContent}
        </AdminLayout>
      );
    
    case 'auth':
      return (
        <AuthLayout
          title="Welcome Back!"
          subtitle="Sign in to manage your family's activities and rewards"
        >
          <View style={styles.authDemo}>
            <Text style={styles.paragraph}>
              This is the authentication layout, used for login and registration pages.
              It features a clean, focused design with optional imagery.
            </Text>
            <Button 
              title="Back to Layouts" 
              onPress={() => setActiveLayout('parent')} 
              style={styles.demoButton}
            />
          </View>
        </AuthLayout>
      );
    
    default:
      return null;
  }
}

const styles = StyleSheet.create({
  layoutSelector: {
    flexDirection: 'row',
    gap: theme.spacing.spacing.sm,
    marginVertical: theme.spacing.spacing.md,
  },
  demoContent: {
    padding: theme.spacing.spacing.lg,
    backgroundColor: theme.colors.surface,
    borderRadius: theme.spacing.borderRadius.lg,
    ...theme.spacing.shadow.md,
  },
  heading: {
    ...theme.typography.textStyle.h2,
    marginBottom: theme.spacing.spacing.md,
    color: theme.colors.textPrimary,
  },
  paragraph: {
    ...theme.typography.textStyle.body,
    marginBottom: theme.spacing.spacing.md,
    color: theme.colors.textPrimary,
  },
  authDemo: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.spacing.borderRadius.lg,
    padding: theme.spacing.spacing.lg,
    ...theme.spacing.shadow.sm,
  },
  demoButton: {
    marginTop: theme.spacing.spacing.md,
  },
});