import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Animated, Easing, StyleProp, ViewStyle, TextStyle } from 'react-native';
import { lightTheme as theme } from '../../styles/theme';

export type TokenDisplaySize = 'sm' | 'md' | 'lg' | 'xl';

interface TokenDisplayProps {
  amount: number;
  size?: TokenDisplaySize;
  animated?: boolean;
  showText?: boolean;
  showPlus?: boolean;
  containerStyle?: StyleProp<ViewStyle>;
  textStyle?: StyleProp<TextStyle>;
}

export const TokenDisplay: React.FC<TokenDisplayProps> = ({
  amount,
  size = 'md',
  animated = false,
  showText = true,
  showPlus = false,
  containerStyle,
  textStyle,
}) => {
  const animationValue = useRef(new Animated.Value(0)).current;
  const [displayAmount, setDisplayAmount] = useState(0);
  
  useEffect(() => {
    if (animated) {
      setDisplayAmount(0);
      animationValue.setValue(0);
      
      Animated.timing(animationValue, {
        toValue: 1,
        duration: 1500,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }).start();
      
      const interval = setInterval(() => {
        setDisplayAmount(prev => {
          if (prev < amount) {
            return Math.min(prev + Math.max(1, Math.floor(amount / 20)), amount);
          }
          clearInterval(interval);
          return amount;
        });
      }, 50);
      
      return () => clearInterval(interval);
    } else {
      setDisplayAmount(amount);
    }
  }, [amount, animated, animationValue]);
  
  const animatedScale = animationValue.interpolate({
    inputRange: [0, 0.5, 0.7, 1],
    outputRange: [1, 1.2, 1.2, 1],
  });
  
  const animatedRotate = animationValue.interpolate({
    inputRange: [0, 0.3, 0.5, 0.7, 1],
    outputRange: ['0deg', '-10deg', '10deg', '-10deg', '0deg'],
  });
  
  const getSizeDimensions = (size: TokenDisplaySize) => {
    switch (size) {
      case 'sm':
        return { containerSize: 24, iconSize: 14, textSize: 12 };
      case 'md':
        return { containerSize: 32, iconSize: 18, textSize: 14 };
      case 'lg':
        return { containerSize: 40, iconSize: 24, textSize: 16 };
      case 'xl':
        return { containerSize: 60, iconSize: 36, textSize: 20 };
      default:
        return { containerSize: 32, iconSize: 18, textSize: 14 };
    }
  };
  
  const { containerSize, iconSize, textSize } = getSizeDimensions(size);
  const formattedAmount = showPlus && amount > 0 ? `+${displayAmount}` : `${displayAmount}`;
  
  return (
    <View style={[styles.container, containerStyle]}>
      <Animated.View
        style={[
          styles.tokenCircle,
          {
            width: containerSize,
            height: containerSize,
            borderRadius: containerSize / 2,
            transform: animated ? [
              { scale: animatedScale },
              { rotate: animatedRotate }
            ] : [],
          },
        ]}
      >
        <Text style={[styles.tokenIcon, { fontSize: iconSize }]}>🪙</Text>
      </Animated.View>
      
      {showText && (
        <Text 
          style={[
            styles.tokenText, 
            { fontSize: textSize },
            textStyle
          ]}
        >
          {formattedAmount}
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  tokenCircle: {
    backgroundColor: theme.colors.accent[100],
    alignItems: 'center',
    justifyContent: 'center',
    ...theme.spacing.shadow.sm,
  },
  tokenIcon: {
    textAlign: 'center',
  },
  tokenText: {
    ...theme.typography.textStyle.body,
    fontWeight: theme.typography.fontWeight.bold,
    color: theme.colors.textPrimary,
    marginLeft: theme.spacing.spacing.xs,
  },
});

export default TokenDisplay;