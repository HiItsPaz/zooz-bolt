import React from 'react';
import { 
  TouchableOpacity, 
  Text, 
  StyleSheet, 
  ActivityIndicator, 
  View, 
  StyleProp, 
  ViewStyle, 
  TextStyle,
  Platform
} from 'react-native';
import { lightTheme as theme } from '../../styles/theme';
import { mergeStyles, conditionalStyle } from '../../utils/styleUtils';

export type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'text';
export type ButtonSize = 'sm' | 'md' | 'lg';

export interface ButtonProps {
  title: string;
  onPress: () => void;
  variant?: ButtonVariant;
  size?: ButtonSize;
  disabled?: boolean;
  loading?: boolean;
  fullWidth?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  textStyle?: StyleProp<TextStyle>;
  accessibilityLabel?: string;
}

export const Button: React.FC<ButtonProps> = ({
  title,
  onPress,
  variant = 'primary',
  size = 'md',
  disabled = false,
  loading = false,
  fullWidth = false,
  leftIcon,
  rightIcon,
  style,
  textStyle,
  accessibilityLabel,
}) => {
  const buttonStyles = [
    styles.button,
    styles[`${variant}Button`],
    styles[`${size}Button`],
    conditionalStyle(fullWidth, styles.fullWidth),
    conditionalStyle(disabled, styles.disabledButton),
    style,
  ];

  const textStyles = [
    styles.text,
    styles[`${variant}Text`],
    styles[`${size}Text`],
    conditionalStyle(disabled, styles.disabledText),
    textStyle,
  ];

  return (
    <TouchableOpacity
      style={mergeStyles(buttonStyles)}
      onPress={onPress}
      disabled={disabled || loading}
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel || title}
      accessibilityState={{ disabled: disabled || loading }}
    >
      {loading ? (
        <ActivityIndicator 
          size="small" 
          color={variant === 'primary' ? theme.colors.neutral[0] : theme.colors.primary[500]} 
        />
      ) : (
        <View style={styles.contentContainer}>
          {leftIcon && <View style={styles.leftIcon}>{leftIcon}</View>}
          <Text style={mergeStyles(textStyles)}>{title}</Text>
          {rightIcon && <View style={styles.rightIcon}>{rightIcon}</View>}
        </View>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    borderRadius: theme.spacing.borderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    ...Platform.select({
      web: {
        cursor: 'pointer',
        userSelect: 'none',
        transitionProperty: 'all',
        transitionDuration: '150ms',
      },
    }),
  },
  fullWidth: {
    width: '100%',
  },
  contentContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  leftIcon: {
    marginRight: theme.spacing.spacing.xs,
  },
  rightIcon: {
    marginLeft: theme.spacing.spacing.xs,
  },
  
  // Variant styles
  primaryButton: {
    backgroundColor: theme.colors.primary[500],
    ...theme.spacing.shadow.md,
  },
  secondaryButton: {
    backgroundColor: theme.colors.secondary[500],
    ...theme.spacing.shadow.md,
  },
  outlineButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: theme.colors.primary[500],
  },
  textButton: {
    backgroundColor: 'transparent',
    paddingHorizontal: 0,
  },
  
  // Size styles
  smButton: {
    paddingVertical: theme.spacing.spacing.xs,
    paddingHorizontal: theme.spacing.spacing.sm,
  },
  mdButton: {
    paddingVertical: theme.spacing.spacing.sm,
    paddingHorizontal: theme.spacing.spacing.md,
  },
  lgButton: {
    paddingVertical: theme.spacing.spacing.md,
    paddingHorizontal: theme.spacing.spacing.lg,
  },
  
  // State styles
  disabledButton: {
    opacity: 0.6,
    ...Platform.select({
      web: {
        cursor: 'not-allowed',
      },
    }),
  },
  
  // Text styles
  text: {
    ...theme.typography.textStyle.button,
  },
  primaryText: {
    color: theme.colors.neutral[0],
  },
  secondaryText: {
    color: theme.colors.neutral[0],
  },
  outlineText: {
    color: theme.colors.primary[500],
  },
  textText: {
    color: theme.colors.primary[500],
  },
  smText: {
    fontSize: theme.typography.fontSize.sm,
  },
  mdText: {
    fontSize: theme.typography.fontSize.md,
  },
  lgText: {
    fontSize: theme.typography.fontSize.lg,
  },
  disabledText: {
    opacity: 0.6,
  },
});

export default Button;