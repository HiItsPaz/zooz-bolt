import React from 'react';
import {
  View,
  StyleSheet,
  StyleProp,
  ViewStyle,
  Text,
  TouchableOpacity,
} from 'react-native';
import { lightTheme as theme } from '../../styles/theme';
import { mergeStyles, conditionalStyle } from '../../utils/styleUtils';

export type CardPadding = 'none' | 'sm' | 'md' | 'lg';
export type CardElevation = 'none' | 'sm' | 'md' | 'lg';

export interface CardProps {
  children: React.ReactNode;
  padding?: CardPadding;
  elevation?: CardElevation;
  hasBorder?: boolean;
  header?: React.ReactNode;
  footer?: React.ReactNode;
  onPress?: () => void;
  style?: StyleProp<ViewStyle>;
  testID?: string;
}

export const Card: React.FC<CardProps> = ({
  children,
  padding = 'md',
  elevation = 'md',
  hasBorder = true,
  header,
  footer,
  onPress,
  style,
  testID,
}) => {
  const cardStyles = [
    styles.card,
    styles[`${padding}Padding`],
    elevation !== 'none' && styles[`${elevation}Elevation`],
    conditionalStyle(hasBorder, styles.bordered),
    style,
  ];

  const CardComponent = onPress ? TouchableOpacity : View;
  const cardProps = onPress
    ? {
        onPress,
        activeOpacity: 0.7,
        accessibilityRole: 'button',
      }
    : {};

  return (
    <CardComponent
      style={mergeStyles(cardStyles)}
      testID={testID}
      {...cardProps}
    >
      {header && <View style={styles.header}>{header}</View>}
      <View style={styles.content}>{children}</View>
      {footer && <View style={styles.footer}>{footer}</View>}
    </CardComponent>
  );
};

// Card Header and Footer Components
export interface CardHeaderProps {
  title?: string;
  subtitle?: string;
  right?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
}

export const CardHeader: React.FC<CardHeaderProps> = ({
  title,
  subtitle,
  right,
  style,
}) => (
  <View style={[styles.headerContainer, style]}>
    <View>
      {title && <Text style={styles.title}>{title}</Text>}
      {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
    </View>
    {right && <View>{right}</View>}
  </View>
);

export interface CardFooterProps {
  children: React.ReactNode;
  style?: StyleProp<ViewStyle>;
}

export const CardFooter: React.FC<CardFooterProps> = ({ children, style }) => (
  <View style={[styles.footerContainer, style]}>{children}</View>
);

const styles = StyleSheet.create({
  card: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.spacing.borderRadius.lg,
    overflow: 'hidden',
    width: '100%',
  },
  bordered: {
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  
  // Padding variations
  nonePadding: {
    padding: 0,
  },
  smPadding: {
    padding: theme.spacing.spacing.sm,
  },
  mdPadding: {
    padding: theme.spacing.spacing.md,
  },
  lgPadding: {
    padding: theme.spacing.spacing.lg,
  },
  
  // Elevation variations
  smElevation: {
    ...theme.spacing.shadow.sm,
  },
  mdElevation: {
    ...theme.spacing.shadow.md,
  },
  lgElevation: {
    ...theme.spacing.shadow.lg,
  },
  
  // Header and footer
  header: {
    marginBottom: theme.spacing.spacing.md,
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.spacing.sm,
  },
  title: {
    ...theme.typography.textStyle.h4,
    color: theme.colors.textPrimary,
  },
  subtitle: {
    ...theme.typography.textStyle.bodySmall,
    color: theme.colors.textSecondary,
    marginTop: 2,
  },
  content: {
    flex: 1,
  },
  footer: {
    marginTop: theme.spacing.spacing.md,
  },
  footerContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginTop: theme.spacing.spacing.sm,
  },
});

export default Card;