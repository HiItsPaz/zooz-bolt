import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  FlatList,
  StyleProp,
  ViewStyle,
  TextStyle,
  Platform,
  ScrollView,
} from 'react-native';
import { lightTheme as theme } from '../../styles/theme';
import { mergeStyles, conditionalStyle } from '../../utils/styleUtils';
import { ChevronDown } from 'lucide-react-native';

export type SelectSize = 'sm' | 'md' | 'lg';

export interface SelectOption {
  label: string;
  value: string;
  disabled?: boolean;
}

export interface SelectGroup {
  label: string;
  options: SelectOption[];
}

export interface SelectProps {
  value: string;
  onChange: (value: string) => void;
  options: SelectOption[] | SelectGroup[];
  placeholder?: string;
  label?: string;
  error?: string;
  helperText?: string;
  disabled?: boolean;
  required?: boolean;
  size?: SelectSize;
  containerStyle?: StyleProp<ViewStyle>;
  selectStyle?: StyleProp<ViewStyle>;
  labelStyle?: StyleProp<TextStyle>;
  optionStyle?: StyleProp<TextStyle>;
  selectedOptionStyle?: StyleProp<TextStyle>;
  errorStyle?: StyleProp<TextStyle>;
  helperStyle?: StyleProp<TextStyle>;
  testID?: string;
  id?: string;
  name?: string;
}

const isSelectGroup = (item: SelectOption | SelectGroup): item is SelectGroup => {
  return (item as SelectGroup).options !== undefined;
};

export const Select: React.FC<SelectProps> = ({
  value,
  onChange,
  options,
  placeholder = 'Select an option',
  label,
  error,
  helperText,
  disabled = false,
  required = false,
  size = 'md',
  containerStyle,
  selectStyle,
  labelStyle,
  optionStyle,
  selectedOptionStyle,
  errorStyle,
  helperStyle,
  testID,
  id,
  name,
}) => {
  const [modalVisible, setModalVisible] = useState(false);
  const [isFocused, setIsFocused] = useState(false);

  const findSelectedLabel = (): string => {
    if (options.length > 0) {
      if (isSelectGroup(options[0])) {
        for (const group of options as SelectGroup[]) {
          const option = group.options.find(opt => opt.value === value);
          if (option) return option.label;
        }
      } else {
        const option = (options as SelectOption[]).find(opt => opt.value === value);
        if (option) return option.label;
      }
    }
    return '';
  };

  const selectedLabel = findSelectedLabel();

  const openModal = () => {
    if (!disabled) {
      setModalVisible(true);
      setIsFocused(true);
    }
  };

  const closeModal = () => {
    setModalVisible(false);
    setIsFocused(false);
  };

  const handleSelectOption = (optionValue: string) => {
    onChange(optionValue);
    closeModal();
  };

  const selectContainerStyles = [
    styles.selectContainer,
    styles[`${size}Select`],
    conditionalStyle(isFocused, styles.focusedSelect),
    conditionalStyle(error, styles.errorSelect),
    conditionalStyle(disabled, styles.disabledSelect),
    selectStyle,
  ];

  if (Platform.OS === 'web') {
    const flattenOptions = (opts: SelectOption[] | SelectGroup[]): React.ReactNode => {
      return opts.map((item, index) => {
        if (isSelectGroup(item)) {
          return (
            <optgroup label={item.label} key={`group-${index}`}>
              {item.options.map((option, optIndex) => (
                <option 
                  value={option.value} 
                  disabled={option.disabled} 
                  key={`option-${index}-${optIndex}`}
                >
                  {option.label}
                </option>
              ))}
            </optgroup>
          );
        } else {
          return (
            <option 
              value={(item as SelectOption).value} 
              disabled={(item as SelectOption).disabled}
              key={`option-${index}`}
            >
              {(item as SelectOption).label}
            </option>
          );
        }
      });
    };

    return (
      <View style={[styles.container, containerStyle]}>
        {label && (
          <Text style={[styles.label, labelStyle]}>
            {label}
            {required && <Text style={styles.requiredStar}> *</Text>}
          </Text>
        )}
        
        <View style={mergeStyles(selectContainerStyles)}>
          <select
            value={value}
            onChange={(e) => onChange(e.target.value)}
            disabled={disabled}
            style={styles.webSelect as any}
            id={id}
            name={name}
            required={required}
            aria-required={required}
            aria-invalid={!!error}
            data-testid={testID}
          >
            {!value && <option value="">{placeholder}</option>}
            {flattenOptions(options)}
          </select>
          <ChevronDown size={16} color={theme.colors.neutral[500]} style={styles.arrow} />
        </View>
        
        {(error || helperText) && (
          <Text 
            style={[
              styles.helperText, 
              error ? [styles.errorText, errorStyle] : helperStyle
            ]}
          >
            {error || helperText}
          </Text>
        )}
      </View>
    );
  }

  const renderOption = ({ item }: { item: SelectOption }) => (
    <TouchableOpacity
      style={[
        styles.option,
        item.disabled && styles.disabledOption,
        item.value === value && styles.selectedOption,
      ]}
      onPress={() => !item.disabled && handleSelectOption(item.value)}
      disabled={item.disabled}
    >
      <Text
        style={[
          styles.optionText,
          item.disabled && styles.disabledOptionText,
          item.value === value && [styles.selectedOptionText, selectedOptionStyle],
          optionStyle,
        ]}
      >
        {item.label}
      </Text>
    </TouchableOpacity>
  );

  const renderGroup = ({ item }: { item: SelectGroup }) => (
    <View style={styles.group}>
      <Text style={styles.groupLabel}>{item.label}</Text>
      {item.options.map((option, index) => (
        <View key={`${item.label}-${index}`}>
          {renderOption({ item: option })}
        </View>
      ))}
    </View>
  );

  return (
    <View style={[styles.container, containerStyle]}>
      {label && (
        <Text style={[styles.label, labelStyle]}>
          {label}
          {required && <Text style={styles.requiredStar}> *</Text>}
        </Text>
      )}
      
      <TouchableOpacity
        style={mergeStyles(selectContainerStyles)}
        onPress={openModal}
        disabled={disabled}
        testID={testID}
        accessibilityLabel={label || placeholder}
        accessibilityRole="button"
        accessibilityState={{ disabled }}
        accessibilityHint="Opens a dialog for selecting an option"
      >
        <Text 
          style={[
            styles.selectText,
            !selectedLabel && styles.placeholderText,
            selectedLabel ? selectedOptionStyle : null,
          ]}
          numberOfLines={1}
        >
          {selectedLabel || placeholder}
        </Text>
        
        <ChevronDown size={16} color={theme.colors.neutral[500]} style={styles.arrow} />
      </TouchableOpacity>
      
      {(error || helperText) && (
        <Text 
          style={[
            styles.helperText, 
            error ? [styles.errorText, errorStyle] : helperStyle
          ]}
        >
          {error || helperText}
        </Text>
      )}
      
      <Modal
        visible={modalVisible}
        transparent
        animationType="slide"
        onRequestClose={closeModal}
      >
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={closeModal}
        >
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{label || 'Select an option'}</Text>
              <TouchableOpacity onPress={closeModal}>
                <Text style={styles.closeButton}>✕</Text>
              </TouchableOpacity>
            </View>
            
            <ScrollView style={styles.optionsList}>
              {options.map((item, index) => (
                <View key={`select-item-${index}`}>
                  {isSelectGroup(item)
                    ? renderGroup({ item: item as SelectGroup })
                    : renderOption({ item: item as SelectOption })}
                </View>
              ))}
            </ScrollView>
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: '100%',
    marginBottom: theme.spacing.spacing.sm,
  },
  label: {
    ...theme.typography.textStyle.body,
    color: theme.colors.textPrimary,
    marginBottom: 4,
  },
  requiredStar: {
    color: theme.colors.semantic.error,
  },
  selectContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: theme.spacing.borderRadius.md,
    backgroundColor: theme.colors.surface,
    position: 'relative',
  },
  webSelect: {
    appearance: 'none',
    backgroundColor: 'transparent',
    border: 'none',
    width: '100%',
    height: '100%',
    paddingRight: 30,
    paddingLeft: theme.spacing.spacing.md,
    fontSize: theme.typography.fontSize.md,
    fontFamily: theme.typography.fontFamily.body,
    color: theme.colors.textPrimary,
    outline: 'none',
  },
  selectText: {
    ...theme.typography.textStyle.body,
    color: theme.colors.textPrimary,
    flex: 1,
    paddingLeft: theme.spacing.spacing.md,
  },
  placeholderText: {
    color: theme.colors.neutral[400],
  },
  arrow: {
    marginRight: theme.spacing.spacing.sm,
  },
  helperText: {
    ...theme.typography.textStyle.bodySmall,
    color: theme.colors.textSecondary,
    marginTop: 4,
  },
  errorText: {
    color: theme.colors.semantic.error,
  },
  
  smSelect: {
    height: 32,
  },
  mdSelect: {
    height: 40,
  },
  lgSelect: {
    height: 48,
  },
  
  focusedSelect: {
    borderColor: theme.colors.primary[500],
    ...Platform.select({
      web: {
        boxShadow: `0 0 0 2px ${theme.colors.primary[200]}`,
      },
    }),
  },
  errorSelect: {
    borderColor: theme.colors.semantic.error,
  },
  disabledSelect: {
    backgroundColor: theme.colors.neutral[100],
    opacity: 0.7,
    ...Platform.select({
      web: {
        cursor: 'not-allowed',
      },
    }),
  },
  
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: theme.colors.surface,
    borderTopLeftRadius: theme.spacing.borderRadius.lg,
    borderTopRightRadius: theme.spacing.borderRadius.lg,
    maxHeight: '70%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: theme.spacing.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  modalTitle: {
    ...theme.typography.textStyle.h4,
    color: theme.colors.textPrimary,
  },
  closeButton: {
    fontSize: 20,
    color: theme.colors.textSecondary,
    padding: theme.spacing.spacing.xs,
  },
  optionsList: {
    paddingVertical: theme.spacing.spacing.sm,
  },
  option: {
    paddingVertical: theme.spacing.spacing.md,
    paddingHorizontal: theme.spacing.spacing.lg,
  },
  selectedOption: {
    backgroundColor: theme.colors.primary[50],
  },
  disabledOption: {
    opacity: 0.5,
  },
  optionText: {
    ...theme.typography.textStyle.body,
    color: theme.colors.textPrimary,
  },
  selectedOptionText: {
    color: theme.colors.primary[600],
    fontWeight: theme.typography.fontWeight.medium,
  },
  disabledOptionText: {
    color: theme.colors.textSecondary,
  },
  group: {
    marginBottom: theme.spacing.spacing.sm,
  },
  groupLabel: {
    ...theme.typography.textStyle.bodySmall,
    color: theme.colors.textSecondary,
    fontWeight: theme.typography.fontWeight.medium,
    paddingHorizontal: theme.spacing.spacing.lg,
    paddingVertical: theme.spacing.spacing.sm,
    backgroundColor: theme.colors.neutral[100],
  },
});

export default Select;