import React, { useState } from 'react';
import {
  View,
  TextInput,
  Text,
  StyleSheet,
  StyleProp,
  ViewStyle,
  TextStyle,
  Platform,
  TouchableOpacity,
} from 'react-native';
import { lightTheme as theme } from '../../styles/theme';
import { mergeStyles, conditionalStyle } from '../../utils/styleUtils';

export type InputSize = 'sm' | 'md' | 'lg';

export interface InputProps {
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
  label?: string;
  error?: string;
  helperText?: string;
  disabled?: boolean;
  required?: boolean;
  size?: InputSize;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  onRightIconPress?: () => void;
  type?: 'text' | 'password' | 'email' | 'number';
  containerStyle?: StyleProp<ViewStyle>;
  inputStyle?: StyleProp<TextStyle>;
  labelStyle?: StyleProp<TextStyle>;
  errorStyle?: StyleProp<TextStyle>;
  helperStyle?: StyleProp<TextStyle>;
  maxLength?: number;
  autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
  autoComplete?: string;
  id?: string;
  name?: string;
  testID?: string;
}

export const Input: React.FC<InputProps> = ({
  value,
  onChangeText,
  placeholder,
  label,
  error,
  helperText,
  disabled = false,
  required = false,
  size = 'md',
  leftIcon,
  rightIcon,
  onRightIconPress,
  type = 'text',
  containerStyle,
  inputStyle,
  labelStyle,
  errorStyle,
  helperStyle,
  maxLength,
  autoCapitalize,
  autoComplete,
  id,
  name,
  testID,
}) => {
  const [isFocused, setIsFocused] = useState(false);

  const handleFocus = () => setIsFocused(true);
  const handleBlur = () => setIsFocused(false);

  const inputContainerStyles = [
    styles.inputContainer,
    styles[`${size}Input`],
    conditionalStyle(isFocused, styles.focusedInput),
    conditionalStyle(error, styles.errorInput),
    conditionalStyle(disabled, styles.disabledInput),
    inputStyle,
  ];

  return (
    <View style={[styles.container, containerStyle]}>
      {label && (
        <View style={styles.labelContainer}>
          <Text style={[styles.label, labelStyle]}>
            {label}
            {required && <Text style={styles.requiredStar}> *</Text>}
          </Text>
        </View>
      )}
      
      <View style={mergeStyles(inputContainerStyles)}>
        {leftIcon && <View style={styles.leftIcon}>{leftIcon}</View>}
        
        <TextInput
          style={styles.input}
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor={theme.colors.neutral[400]}
          editable={!disabled}
          onFocus={handleFocus}
          onBlur={handleBlur}
          secureTextEntry={type === 'password'}
          keyboardType={
            type === 'email' 
              ? 'email-address' 
              : type === 'number' 
                ? 'numeric' 
                : 'default'
          }
          maxLength={maxLength}
          autoCapitalize={autoCapitalize}
          autoComplete={Platform.OS === 'web' ? autoComplete : undefined}
          id={Platform.OS === 'web' ? id : undefined}
          testID={testID}
          accessibilityLabel={label || placeholder}
          accessibilityRole="text"
          accessibilityState={{ disabled }}
          accessibilityRequired={required}
        />
        
        {rightIcon && (
          <TouchableOpacity 
            style={styles.rightIcon} 
            onPress={onRightIconPress}
            disabled={!onRightIconPress}
            accessibilityRole={onRightIconPress ? "button" : undefined}
          >
            {rightIcon}
          </TouchableOpacity>
        )}
      </View>
      
      {(error || helperText) && (
        <Text 
          style={[
            styles.helperText, 
            error ? styles.errorText : helperStyle
          ]}
        >
          {error || helperText}
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: '100%',
    marginBottom: theme.spacing.spacing.sm,
  },
  labelContainer: {
    marginBottom: theme.spacing.spacing.xs,
  },
  label: {
    ...theme.typography.textStyle.body,
    color: theme.colors.textPrimary,
    marginBottom: 4,
  },
  requiredStar: {
    color: theme.colors.semantic.error,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: theme.spacing.borderRadius.md,
    backgroundColor: theme.colors.surface,
  },
  input: {
    flex: 1,
    color: theme.colors.textPrimary,
    ...theme.typography.textStyle.body,
    paddingVertical: 0, // Fix for react-native
  },
  leftIcon: {
    marginLeft: theme.spacing.spacing.sm,
    marginRight: theme.spacing.spacing.xs,
  },
  rightIcon: {
    marginRight: theme.spacing.spacing.sm,
    marginLeft: theme.spacing.spacing.xs,
  },
  helperText: {
    ...theme.typography.textStyle.bodySmall,
    color: theme.colors.textSecondary,
    marginTop: 4,
  },
  errorText: {
    color: theme.colors.semantic.error,
  },
  
  // Size variations
  smInput: {
    height: 32,
    paddingHorizontal: theme.spacing.spacing.sm,
  },
  mdInput: {
    height: 40,
    paddingHorizontal: theme.spacing.spacing.md,
  },
  lgInput: {
    height: 48,
    paddingHorizontal: theme.spacing.spacing.md,
  },
  
  // State variations
  focusedInput: {
    borderColor: theme.colors.primary[500],
    ...Platform.select({
      web: {
        outlineWidth: 0,
        boxShadow: `0 0 0 2px ${theme.colors.primary[200]}`,
      },
    }),
  },
  errorInput: {
    borderColor: theme.colors.semantic.error,
  },
  disabledInput: {
    backgroundColor: theme.colors.neutral[100],
    opacity: 0.7,
    ...Platform.select({
      web: {
        cursor: 'not-allowed',
      },
    }),
  },
});

export default Input;