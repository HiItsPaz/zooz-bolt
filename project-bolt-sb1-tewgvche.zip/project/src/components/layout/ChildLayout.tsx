import React from 'react';
import { View, StyleSheet, ScrollView, SafeAreaView, Text, TouchableOpacity } from 'react-native';
import Header from './Header';
import Footer from './Footer';
import { lightTheme as theme } from '../../styles/theme';
import { Home, Scroll, Coins, Trophy } from 'lucide-react-native';

interface ChildLayoutProps {
  children: React.ReactNode;
  userName?: string;
  tokenBalance?: number;
  unreadNotifications?: number;
  onNotificationsPress?: () => void;
  onProfilePress?: () => void;
  onMenuItemPress?: (item: string) => void;
}

export const ChildLayout: React.FC<ChildLayoutProps> = ({
  children,
  userName,
  tokenBalance = 0,
  unreadNotifications = 0,
  onNotificationsPress,
  onProfilePress,
  onMenuItemPress,
}) => {
  return (
    <SafeAreaView style={styles.container}>
      <Header
        userRole="child"
        userName={userName}
        unreadNotifications={unreadNotifications}
        onNotificationsPress={onNotificationsPress}
        onProfilePress={onProfilePress}
        onMenuItemPress={onMenuItemPress}
      />
      <ScrollView 
        style={styles.content}
        contentContainerStyle={styles.contentContainer}
      >
        <View style={styles.tokenBar}>
          <View style={styles.tokenDisplay}>
            <Coins size={20} color={theme.colors.neutral[0]} />
            <Text style={styles.tokenCount}>{tokenBalance}</Text>
          </View>
        </View>
        <View style={styles.mainContent}>
          {children}
        </View>
      </ScrollView>
      <Footer showChildFooter={true} />
      <View style={styles.gameNavBar}>
        <TouchableOpacity 
          style={styles.navButton}
          onPress={() => onMenuItemPress?.('home')}
        >
          <Home size={24} color={theme.colors.neutral[0]} />
          <Text style={styles.navLabel}>Home</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.navButton}
          onPress={() => onMenuItemPress?.('quests')}
        >
          <Scroll size={24} color={theme.colors.neutral[0]} />
          <Text style={styles.navLabel}>Quests</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.navButton}
          onPress={() => onMenuItemPress?.('tokens')}
        >
          <Coins size={24} color={theme.colors.neutral[0]} />
          <Text style={styles.navLabel}>Tokens</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.navButton}
          onPress={() => onMenuItemPress?.('achievements')}
        >
          <Trophy size={24} color={theme.colors.neutral[0]} />
          <Text style={styles.navLabel}>Prizes</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    minHeight: '100%',
  },
  tokenBar: {
    backgroundColor: theme.colors.primary[400],
    paddingVertical: theme.spacing.spacing.xs,
    paddingHorizontal: theme.spacing.spacing.md,
    justifyContent: 'flex-end',
    alignItems: 'flex-end',
  },
  tokenDisplay: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.primary[300],
    paddingHorizontal: theme.spacing.spacing.sm,
    paddingVertical: theme.spacing.spacing.xs,
    borderRadius: 20,
  },
  tokenCount: {
    ...theme.typography.textStyle.body,
    fontWeight: theme.typography.fontWeight.bold,
    color: theme.colors.neutral[0],
    marginLeft: theme.spacing.spacing.xs,
  },
  mainContent: {
    flex: 1,
    maxWidth: 1200,
    width: '100%',
    marginHorizontal: 'auto',
    padding: theme.spacing.spacing.md,
  },
  gameNavBar: {
    flexDirection: 'row',
    backgroundColor: theme.colors.primary[500],
    justifyContent: 'space-around',
    paddingVertical: theme.spacing.spacing.sm,
    borderTopWidth: 1,
    borderTopColor: theme.colors.primary[600],
  },
  navButton: {
    alignItems: 'center',
    minWidth: 60,
  },
  navLabel: {
    ...theme.typography.textStyle.bodySmall,
    color: theme.colors.neutral[0],
    marginTop: theme.spacing.spacing.xs,
  },
});

export default ChildLayout;