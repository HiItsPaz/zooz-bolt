import React from 'react';
import { View, StyleSheet, Text, TouchableOpacity, Platform } from 'react-native';
import { lightTheme as theme } from '../../styles/theme';
import { User, Settings, Users, Bell } from 'lucide-react-native';

// Rest of the file remains unchanged...