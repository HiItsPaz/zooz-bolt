import React from 'react';
import { View, StyleSheet, ScrollView, SafeAreaView } from 'react-native';
import Header from './Header';
import Footer from './Footer';
import { lightTheme as theme } from '../../styles/theme';

interface ParentLayoutProps {
  children: React.ReactNode;
  userName?: string;
  unreadNotifications?: number;
  onNotificationsPress?: () => void;
  onProfilePress?: () => void;
  onMenuItemPress?: (item: string) => void;
  footerLinks?: Array<{ id: string; label: string; onPress: () => void }>;
}

export const ParentLayout: React.FC<ParentLayoutProps> = ({
  children,
  userName,
  unreadNotifications = 0,
  onNotificationsPress,
  onProfilePress,
  onMenuItemPress,
  footerLinks = [],
}) => {
  return (
    <SafeAreaView style={styles.container}>
      <Header
        userRole="parent"
        userName={userName}
        unreadNotifications={unreadNotifications}
        onNotificationsPress={onNotificationsPress}
        onProfilePress={onProfilePress}
        onMenuItemPress={onMenuItemPress}
      />
      <ScrollView 
        style={styles.content}
        contentContainerStyle={styles.contentContainer}
      >
        <View style={styles.mainContent}>
          {children}
        </View>
      </ScrollView>
      <Footer links={footerLinks} />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    minHeight: '100%',
  },
  mainContent: {
    flex: 1,
    maxWidth: 1200,
    width: '100%',
    marginHorizontal: 'auto',
    padding: theme.spacing.spacing.md,
  },
});

export default ParentLayout;