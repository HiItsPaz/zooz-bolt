import React from 'react';
import { View, StyleSheet, ScrollView, SafeAreaView, Text, TouchableOpacity } from 'react-native';
import Header from './Header';
import Footer from './Footer';
import { lightTheme as theme } from '../../styles/theme';
import { LayoutDashboard, Users, FileText, LineChart, Settings } from 'lucide-react-native';

interface AdminLayoutProps {
  children: React.ReactNode;
  userName?: string;
  unreadNotifications?: number;
  onNotificationsPress?: () => void;
  onProfilePress?: () => void;
  onMenuItemPress?: (item: string) => void;
  footerLinks?: Array<{ id: string; label: string; onPress: () => void }>;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  children,
  userName,
  unreadNotifications = 0,
  onNotificationsPress,
  onProfilePress,
  onMenuItemPress,
  footerLinks = [],
}) => {
  const sidebarItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'users', label: 'Users', icon: Users },
    { id: 'templates', label: 'Templates', icon: FileText },
    { id: 'reports', label: 'Reports', icon: LineChart },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <Header
        userRole="admin"
        userName={userName}
        unreadNotifications={unreadNotifications}
        onNotificationsPress={onNotificationsPress}
        onProfilePress={onProfilePress}
        onMenuItemPress={onMenuItemPress}
      />
      <View style={styles.contentContainer}>
        <View style={styles.sidebar}>
          <View style={styles.sidebarContent}>
            {sidebarItems.map((item) => {
              const Icon = item.icon;
              return (
                <TouchableOpacity
                  key={item.id}
                  style={styles.sidebarItem}
                  onPress={() => onMenuItemPress?.(item.id)}
                >
                  <Icon size={20} color={theme.colors.neutral[400]} />
                  <Text style={styles.sidebarLabel}>{item.label}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>
        <ScrollView style={styles.content}>
          <View style={styles.mainContent}>
            {children}
          </View>
        </ScrollView>
      </View>
      <Footer links={footerLinks} />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  contentContainer: {
    flex: 1,
    flexDirection: 'row',
  },
  sidebar: {
    width: 240,
    backgroundColor: theme.colors.neutral[900],
    borderRightWidth: 1,
    borderRightColor: theme.colors.neutral[800],
  },
  sidebarContent: {
    paddingVertical: theme.spacing.spacing.md,
  },
  sidebarItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: theme.spacing.spacing.sm,
    paddingHorizontal: theme.spacing.spacing.md,
    marginBottom: theme.spacing.spacing.xs,
  },
  sidebarLabel: {
    ...theme.typography.textStyle.body,
    color: theme.colors.neutral[400],
    marginLeft: theme.spacing.spacing.sm,
  },
  content: {
    flex: 1,
  },
  mainContent: {
    padding: theme.spacing.spacing.lg,
    maxWidth: 1200,
    width: '100%',
  },
});

export default AdminLayout;