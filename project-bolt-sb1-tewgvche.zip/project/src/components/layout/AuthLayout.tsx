import React from 'react';
import { View, StyleSheet, Text, ScrollView, SafeAreaView, Image } from 'react-native';
import Footer from './Footer';
import { lightTheme as theme } from '../../styles/theme';
import { APP_NAME } from '../../constants';

interface AuthLayoutProps {
  children: React.ReactNode;
  title: string;
  subtitle?: string;
  isChildAuth?: boolean;
}

export const AuthLayout: React.FC<AuthLayoutProps> = ({
  children,
  title,
  subtitle,
  isChildAuth = false,
}) => {
  const footerLinks = [
    { id: 'privacy', label: 'Privacy Policy', onPress: () => {} },
    { id: 'terms', label: 'Terms of Service', onPress: () => {} },
    { id: 'help', label: 'Help Center', onPress: () => {} },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
      >
        <View style={styles.authContainer}>
          <View style={styles.contentSection}>
            <View style={styles.headerSection}>
              <Text style={[styles.appName, isChildAuth && styles.childAppName]}>
                {APP_NAME}
              </Text>
              <Text style={[styles.title, isChildAuth && styles.childTitle]}>
                {title}
              </Text>
              {subtitle && (
                <Text
                  style={[styles.subtitle, isChildAuth && styles.childSubtitle]}
                >
                  {subtitle}
                </Text>
              )}
            </View>

            <View style={[styles.formSection, isChildAuth && styles.childFormSection]}>
              {children}
            </View>
          </View>
          
          <View style={styles.imageSection}>
            <Image
              source={{ 
                uri: isChildAuth 
                  ? 'https://images.unsplash.com/photo-1628258334105-2a0b3d6efee1'
                  : 'https://images.unsplash.com/photo-1536640712-4d4c36ff0e4e'
              }}
              style={styles.backgroundImage}
              resizeMode="cover"
            />
          </View>
        </View>
      </ScrollView>
      <Footer links={footerLinks} />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    minHeight: '100%',
    flexGrow: 1,
  },
  authContainer: {
    flex: 1,
    flexDirection: 'row',
    maxWidth: 1200,
    width: '100%',
    marginHorizontal: 'auto',
  },
  contentSection: {
    flex: 1,
    padding: theme.spacing.spacing.xl,
    justifyContent: 'center',
  },
  headerSection: {
    marginBottom: theme.spacing.spacing.xl,
  },
  appName: {
    ...theme.typography.textStyle.h2,
    color: theme.colors.primary[500],
    marginBottom: theme.spacing.spacing.md,
  },
  childAppName: {
    color: theme.colors.secondary[500],
  },
  title: {
    ...theme.typography.textStyle.h3,
    color: theme.colors.textPrimary,
    marginBottom: theme.spacing.spacing.sm,
  },
  childTitle: {
    ...theme.typography.textStyle.h2,
    color: theme.colors.primary[500],
  },
  subtitle: {
    ...theme.typography.textStyle.body,
    color: theme.colors.textSecondary,
  },
  childSubtitle: {
    ...theme.typography.textStyle.bodyLarge,
    color: theme.colors.secondary[700],
  },
  formSection: {
    maxWidth: 400,
  },
  childFormSection: {
    maxWidth: 500,
  },
  imageSection: {
    flex: 1,
    display: 'none',
    ...Platform.select({
      web: {
        display: 'flex',
        '@media (min-width: 768px)': {
          display: 'flex',
        },
      },
    }),
  },
  backgroundImage: {
    flex: 1,
    borderRadius: theme.spacing.borderRadius.lg,
    overflow: 'hidden',
  },
});

export default AuthLayout;