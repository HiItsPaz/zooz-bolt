import React, { useState } from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import { ThemeProvider } from './context/ThemeContext';
import { MockDataProvider, useMockData } from './context/MockDataContext';
import Activities from './pages/child/Activities';
import ActivityDetail from './pages/child/ActivityDetail';
import { lightTheme as theme } from './styles/theme';

// App screens enum
enum AppScreen {
  Activities = 'activities',
  ActivityDetail = 'activityDetail',
}

const App = () => {
  const [activeScreen, setActiveScreen] = useState<AppScreen>(AppScreen.Activities);
  const [selectedActivityId, setSelectedActivityId] = useState<string | null>(null);
  
  const handleViewActivity = (activityId: string) => {
    setSelectedActivityId(activityId);
    setActiveScreen(AppScreen.ActivityDetail);
  };
  
  const handleBackToActivities = () => {
    setActiveScreen(AppScreen.Activities);
    setSelectedActivityId(null);
  };
  
  return (
    <ThemeProvider>
      <MockDataProvider>
        <SafeAreaView style={styles.container}>
          {activeScreen === AppScreen.Activities ? (
            <Activities onSelectActivity={handleViewActivity} />
          ) : (
            <ActivityDetail
              activityId={selectedActivityId!}
              onBack={handleBackToActivities}
            />
          )}
        </SafeAreaView>
      </MockDataProvider>
    </ThemeProvider>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
});

export default App;